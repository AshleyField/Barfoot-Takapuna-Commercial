<div class="swiper-slide">
	<div class="hero">
		<div class="hero-overlay" style="background-image: url('<?php the_field('banner_image'); ?>');">
			<div class="hero-content">
				<h1><?php the_title(); ?></h1>
				<h2><?php the_field('subheading') ?></h2>
				<div class="horizontal-bar"></div>
			</div>
		</div>
	</div>
</div>