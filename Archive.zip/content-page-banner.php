<div class="page-banner" style="background-image: url('<?php echo get_field('banner_image'); ?>')">
	
	<div class="page-banner-head">
		<?php echo '<h1>'.get_the_title() . '</h1>'; ?>	
	</div>
</div>